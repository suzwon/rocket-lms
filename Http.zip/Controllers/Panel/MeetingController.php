<?php

namespace App\Http\Controllers\Panel;

use App\Http\Controllers\Controller;
use App\Mixins\RegistrationPackage\UserPackage;
use App\Models\Meeting;
use App\Models\MeetingPackage;
use App\Models\MeetingTime;
use \Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MeetingController extends Controller
{

    public function setting(Request $request)
    {
        $this->authorize("panel_meetings_settings");

        $user = auth()->user();

        $meeting = Meeting::where('creator_id', $user->id)
            ->with([
                'meetingTimes'
            ])
            ->first();

        if (empty($meeting)) {
            $meeting = Meeting::create([
                'creator_id' => $user->id,
                'created_at' => time()
            ]);
        }

        $meetingTimes = [];
        foreach ($meeting->meetingTimes->groupBy('day_label') as $day => $meetingTime) {
            $times = 0;

            foreach ($meetingTime as $time) {

                $meetingTimes[$day]["times"][] = $time;

                $explodetime = explode('-', $time->time);
                $times += strtotime($explodetime[1]) - strtotime($explodetime[0]);
            }

            $meetingTimes[$day]["hours_available"] = round($times / 3600, 2);
        }

        $locale = $request->get('locale', getDefaultLocale());
        $meetingPackagesFeatureStatus = !empty(getMeetingPackagesSettings("status"));

        $data = [
            'pageTitle' => trans('meeting.meeting_setting_page_title'),
            'meeting' => $meeting,
            'meetingTimes' => $meetingTimes,
            'meetingPackagesFeatureStatus' => $meetingPackagesFeatureStatus,
            'locale' => mb_strtolower($locale),
        ];

        if ($meetingPackagesFeatureStatus) {
            $meetingPackagesController = (new MeetingPackagesController());
            $meetingPackagesData = $meetingPackagesController->index($request);

            $data = array_merge($data, $meetingPackagesData);

            // Edit Page
            $meetingPackageId = $request->get('package');
            if (!empty($meetingPackageId)) {
                $data = array_merge($data, $meetingPackagesController->edit($meetingPackageId));
            }
        }

        return view("design_1.panel.meeting.settings.index", $data);
    }

    public function update(Request $request, $id)
    {
        $this->authorize("panel_meetings_settings");

        $user = auth()->user();
        $data = $request->all();

        $groupMeeting = (!empty($data['group_meeting']) and $data['group_meeting'] == 'on');
        $inPerson = (!empty($data['in_person']) and $data['in_person'] == 'on');

        $rules = [
            'amount' => 'required',
            'discount' => 'nullable',
            'disabled' => 'nullable',
            'in_person_amount' => 'required_if:in_person,on',
            'online_group_min_student' => 'required_if:group_meeting,on',
            'online_group_max_student' => 'required_if:group_meeting,on',
            'online_group_amount' => 'required_if:group_meeting,on',
        ];

        if ($groupMeeting and $inPerson) {
            $rules = array_merge($rules, [
                'in_person_group_min_student' => 'required_if:in_person,on',
                'in_person_group_max_student' => 'required_if:in_person,on',
                'in_person_group_amount' => 'required_if:in_person,on',
            ]);
        }

        $validator = Validator::make($data, $rules);

        if ($validator->fails()) {
            return response([
                'code' => 422,
                'errors' => $validator->errors(),
            ], 422);
        }

        $meeting = Meeting::where('id', $id)
            ->where('creator_id', $user->id)
            ->first();

        if (!empty($meeting)) {
            $meeting->update([
                'amount' => convertPriceToDefaultCurrency($data['amount']),
                'discount' => $data['discount'],
                'disabled' => empty($data['enable']) ? 1 : 0,
                'enable_meeting_packages' => (!empty($data['enable_meeting_packages']) and $data['enable_meeting_packages'] == 'on'),
                'in_person' => $inPerson,
                'in_person_amount' => $inPerson ? convertPriceToDefaultCurrency($data['in_person_amount']) : null,
                'group_meeting' => $groupMeeting,
                'online_group_min_student' => $groupMeeting ? $data['online_group_min_student'] : null,
                'online_group_max_student' => $groupMeeting ? $data['online_group_max_student'] : null,
                'online_group_amount' => $groupMeeting ? convertPriceToDefaultCurrency($data['online_group_amount']) : null,
                'in_person_group_min_student' => ($groupMeeting and $inPerson) ? $data['in_person_group_min_student'] : null,
                'in_person_group_max_student' => ($groupMeeting and $inPerson) ? $data['in_person_group_max_student'] : null,
                'in_person_group_amount' => ($groupMeeting and $inPerson) ? convertPriceToDefaultCurrency($data['in_person_group_amount']) : null,
            ]);

            return response()->json([
                'code' => 200
            ], 200);
        }

        return response()->json([], 422);
    }

    public function saveTime(Request $request)
    {
        $user = auth()->user();
        $meeting = Meeting::where('creator_id', $user->id)->first();
        $data = $request->all();

        $validator = Validator::make($data, [
            'day' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        if ($validator->fails()) {
            return response([
                'code' => 422,
                'errors' => $validator->errors(),
            ], 422);
        }

        $checkValidation = $this->checkExtraValidation($data);
        if ($checkValidation != 'ok') {
            return $checkValidation;
        }

        if (!empty($meeting)) {

            $userPackage = new UserPackage();
            $userMeetingCountLimited = $userPackage->checkPackageLimit('meeting_count');

            if ($userMeetingCountLimited) {
                return response()->json([
                    'registration_package_limited' => $userMeetingCountLimited
                ], 200);
            }

            $time = trim($data['start_time']) . '-' . trim($data['end_time']);
            $day = $data['day'];
            $meetingType = $data['meeting_type'];
            $description = $data['description'] ?? null;

            $checkTime = MeetingTime::where('meeting_id', $meeting->id)
                ->where('day_label', $day)
                ->where('time', $time)
                ->first();

            if (empty($checkTime)) {
                MeetingTime::create([
                    'meeting_id' => $meeting->id,
                    'meeting_type' => $meetingType,
                    'day_label' => $day,
                    'time' => $time,
                    'description' => $description,
                    'created_at' => time(),
                ]);
            }

            return response()->json([
                'code' => 200
            ], 200);
        }

        return response()->json([], 422);
    }

    private function checkExtraValidation($data)
    {
        $errors = [];

        if (!$this->chackTimeFormat($data['start_time'])) {
            $errors['start_time'] = [trans('update.the_selected_format_is_incorrect')];
        }

        if (!$this->chackTimeFormat($data['end_time'])) {
            $errors['end_time'] = [trans('update.the_selected_format_is_incorrect')];
        }

        $start_time = date("H:i", strtotime($data['start_time']));
        $end_time = date("H:i", strtotime($data['end_time']));

        if (strtotime($end_time) <= strtotime($start_time) and empty($errors['end_time'])) {
            $errors['end_time'] = [trans('update.the_end_time_must_be_greater_than_the_start_time')];
        }

        if (!empty($errors) and count($errors)) {
            return response([
                'code' => 422,
                'errors' => $errors,
            ], 422);
        }

        return 'ok';
    }

    private function chackTimeFormat($time)
    {
        return preg_match("/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/", $time);
    }

    public function deleteTime(Request $request)
    {
        $user = auth()->user();
        $meeting = Meeting::where('creator_id', $user->id)->first();
        $data = $request->all();
        $timeIds = $data['time_id'];

        if (!empty($meeting) and !empty($timeIds) and is_array($timeIds)) {

            $meetingTimes = MeetingTime::whereIn('id', $timeIds)
                ->where('meeting_id', $meeting->id)
                ->get();

            if (!empty($meetingTimes)) {
                foreach ($meetingTimes as $meetingTime) {
                    $meetingTime->delete();
                }

                return response()->json([], 200);
            }
        }

        return response()->json([], 422);
    }

    public function temporaryDisableMeetings(Request $request)
    {
        $user = auth()->user();
        $data = $request->all();

        $meeting = Meeting::where('creator_id', $user->id)
            ->first();

        if (!empty($meeting)) {
            $meeting->update([
                'disabled' => (!empty($data['disable']) and $data['disable'] == 'true') ? 1 : 0,
            ]);

            return response()->json([
                'code' => 200
            ], 200);
        }

        return response()->json([], 422);
    }

    public function getMeetingTimeModal(Request $request)
    {
        $user = auth()->user();

        $html = (string)view()->make("design_1.panel.meeting.settings.modals.add_meeting_time_modal");

        return response()->json([
            'code' => 200,
            'html' => $html
        ]);
    }
}
